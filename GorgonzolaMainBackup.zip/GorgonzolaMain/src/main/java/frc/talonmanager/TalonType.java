package frc.talonmanager;
public enum TalonType {
    DRIVETRAIN, SHOULDER, WRIST, CLIMBER, INTAKE;
}