package frc.components;
public enum ArmControlState {
    AUTO, POSITON_MANUAL, FULL_MANUAL;
}